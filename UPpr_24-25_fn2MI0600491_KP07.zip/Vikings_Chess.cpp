
#include <iostream>
#include "GameEngine.h"
using namespace std;


/**
 *
 * Solution to course project #7
 * Introduction to programing course
 * Faculty of Mathematics and Informatics of Sofia University
 * Winter semester 2024/2025
 *
 * @author Teodor Patov
 * @idnumber 2MI0600491
 * @compiler VC
 *
 * <file with main function for the game>
 */


int main()
{
	runGame();

}
